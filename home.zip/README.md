# Baxi Website
 This is the official Homepage for our discord Bot Baxi. 

## Links
 - DEMO: http://sparkle2.pyropixle.com:1659/baxi/ (Recommended on the computer)
 - DISCORD: https://link.pyropixle.com/discord
 - BAXI INVITE: https://link.pyropixle.com/baxi
